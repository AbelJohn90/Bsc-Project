---
name: New external evaluation(s)
about: To submit new evaluations of models in the Model Zoo
title: "[New evaluation] <>"
labels: ''
assignees: ''

---

## Target model
+ **Model identifier(s):** <as in the Model Zoo>
+ **Leaderboard(s):** <dataset and threat model>

## New evaluation
+ **Link to adversarial images:** <it should be a `.pt` tensor of the same size of the corresponding test set>
+ **Robust accuracy:**
+ **Author(s):**
+ **Description of the method used:** <it might be link to a paper, code or short description if the first two are not available>
